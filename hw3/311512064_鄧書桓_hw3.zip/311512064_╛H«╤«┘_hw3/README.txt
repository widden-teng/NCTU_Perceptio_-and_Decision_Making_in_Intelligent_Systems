1.輸入python task1.py以獲得2D語意地圖
2.輸入 python basic_rrt -demo 以執行給起始點與固定目標物為終點的任務
3.輸入python load.py來執行模擬(輸入目標點並按q)並儲存影片